const sliders = document.querySelectorAll('.slider');

sliders.forEach((slider) => {
  const sliderList = slider.querySelector('.slider__list');
  const slides = slider.querySelectorAll('.slider__item');

  const sliderControllerDots = document.createElement('div');
  const sliderDot = document.createElement('span');

  sliderControllerDots.className = 'slider__dots';
  sliderDot.className = 'slider__dot';

  for (let i = 0; i < slides.length; i++) {
    sliderControllerDots.innerHTML += sliderDot.outerHTML;
  }

  slider.append(sliderControllerDots);

  const sliderDots = slider.querySelectorAll('.slider__dot');
  let isDragging = false;
  let animationID = 0;
  let startPos = 0;
  let currentTranslate = 0;
  let prevTranslate = 0;
  let sliderListGap = 0;
  let sliderContentWidth = 0;
  let sliderPadding = 0;
  let currentIndex = 0;

  sliderDots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
      if (currentIndex == index) return;
      currentIndex = index;
      editSlideClass(currentIndex);
      setPositionByIndex(currentIndex);
    });
  });

  slides.forEach((slide, index) => {
    slide.addEventListener('touchstart', touchStart(index));
    slide.addEventListener('touchend', touchEnd(index));
    slide.addEventListener('touchmove', touchMove);
    slide.addEventListener('mousedown', touchStart(index));
    slide.addEventListener('mouseup', touchEnd(index));
    slide.addEventListener('mousemove', touchMove);
    slide.addEventListener('mouseleave', touchEnd(index));
  });

  function blockResize() {
    sliderPadding = Number(window.getComputedStyle(slider, null).paddingLeft.replace(/px/g, ''));
    sliderContentWidth = slider.clientWidth - sliderPadding * 2;
    sliderListGap = Number(window.getComputedStyle(sliderList, null).gap.replace(/px/g, ''));
    sliderList.style.gridTemplateColumns = `repeat(${slides.length}, ${sliderContentWidth}px)`;
  }

  function editSlideClass(index) {
    for (let i = 0; i < slides.length; i++) {
      removeClassName(i);
    }
    addClassName(index);
  }

  function addClassName(index) {
    slides[index].classList.add('active');
    sliderDots[index].classList.add('active');
  }

  function removeClassName(index) {
    slides[index].classList.remove('active');
    sliderDots[index].classList.remove('active');
  }

  function getPositionX(event) {
    return event.type.includes('mouse') ? event.pageX : event.touches[0].clientX;
  }

  function touchStart(index) {
    return (event) => {
      startPos = getPositionX(event);
      animationID = requestAnimationFrame(animation);
      isDragging = true;
      slides[index].classList.add('slider__item--grabbing');
    };
  }

  function touchMove(event) {
    if (isDragging) {
      const currentPosition = getPositionX(event);
      return (currentTranslate = prevTranslate + currentPosition - startPos);
    }
  }

  function touchEnd(index) {
    return () => {
      cancelAnimationFrame(animationID);
      isDragging = false;
      const movedBy = currentTranslate - prevTranslate;

      if (movedBy < -100 && currentIndex < slides.length - 1) currentIndex++;
      if (movedBy > 100 && currentIndex > 0) currentIndex--;

      slides[index].classList.remove('slider__item--grabbing');
      setPositionByIndex(currentIndex);
    };
  }

  function animation() {
    setSliderPosition();
    if (isDragging) requestAnimationFrame(animation);
  }

  function setPositionByIndex(index) {
    editSlideClass(index);
    currentTranslate = index * -(sliderContentWidth + sliderListGap);
    prevTranslate = currentTranslate;
    setSliderPosition();
  }

  function setSliderPosition() {
    sliderList.style.transform = `translateX(${currentTranslate}px)`;
  }

  blockResize();
  setPositionByIndex(currentIndex);

  window.addEventListener('resize', () => {
    blockResize();
    setPositionByIndex(currentIndex);
  });
});
